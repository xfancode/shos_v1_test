@echo off
title ShOs Runner
if exist "%systemroot%\SysWOW64" (
    set "AHK_PATH=system\tools\ahk\ahk64.exe"
) else (
    set "AHK_PATH=system\tools\ahk\ahk32.exe"
)
start "" "%AHK_PATH%" "scripts\shos_keys.ahk"
taskkill /f /im explorer.exe :: закрытие оболочки
start "" "LockScreen.hta"
exit /b
