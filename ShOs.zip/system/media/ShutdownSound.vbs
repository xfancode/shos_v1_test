Set WMP = WScript.CreateObject("MediaPlayer.MediaPlayer", "WMP_")
WMP.Open "shutdown.mp3"
WMP.Play
WScript.Sleep 1000