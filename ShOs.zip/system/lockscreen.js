document.getElementById('avatar-icon').innerHTML = Icons.user;
document.getElementById('power-icon').innerHTML = Icons.power;

function loadWallpaper() {
    let img = localStorage.getItem('shos_wallpaper_lockscreen') || 'system/default.svg';
    document.getElementById('wallpaper').src = img;
}

function updateClock() {
    let d = new Date();
    document.getElementById('clock').textContent = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
}

function login() {
    if (document.getElementById('passwordInput').value === '123123') {
        window.open("desktop.hta.html");
        window.close();
    } else {
        document.getElementById('errorMessage').textContent = 'Неверный пароль';
        document.getElementById('passwordInput').value = '';
    }
}

function showPowerMenu() {
    new ActiveXObject("WScript.Shell").Run('scripts\\spmenu.cmd');
}

document.getElementById('passwordInput').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') login();
});

window.onload = function() {
    loadWallpaper();
    updateClock();
    setInterval(updateClock, 1000);
};