@echo off
chcp 65001 >nul
title ShOs Modification Tool

:main
cls
echo  ShOs Modification Tool
echo.
echo  1) Перезагрузка в Windows
echo  2) Полное выключение ПК
echo  3) Сброс настроек ShOs (локальное хранилище)
echo  4) Очистка временных файлов ShOs
echo  5) Пересоздать ярлык на рабочем столе
echo  6) Открыть папку ShOs
echo  7) Скрыть папку ShOs
echo  8) Показать папку ShOs
echo  9) Создать резервную копию пользователя '%username%'
echo 10) Выход
echo.
choice /c 123456789A /n

if errorlevel 10 exit /b
if errorlevel 9 goto backup
if errorlevel 8 goto show_folder
if errorlevel 7 goto hide_folder
if errorlevel 6 goto open_folder
if errorlevel 5 goto shortcut
if errorlevel 4 goto clean_temp
if errorlevel 3 goto reset_settings
if errorlevel 2 goto shutdown
if errorlevel 1 goto reboot

:reboot
cls
shutdown /r /t 3
exit /b

:shutdown
cls
echo Выключение ПК...
timeout /t 2 /nobreak >nul
shutdown /s /t 0
exit /b

:reset_settings
cls
echo Сброс настроек ShOs
echo.
echo  1) Сбросить настройки рабочего стола
echo  2) Сбросить все настройки ShOs
echo.
choice /c 12 /n
if errorlevel 2 (
    powershell -Command "Add-Type -AssemblyName System.Web; $html = New-Object -ComObject 'HTMLFile'; $html.write(''); $win = @($html.parentWindow); $win[0].localStorage.clear()"
    echo Все настройки удалены.
) else (
    reg delete "HKCU\Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BROWSER_EMULATION" /v desktop.hta >nul 2>&1
    echo Настройки рабочего стола сброшены.
)
timeout /t 2 /nobreak >nul
goto main

:clean_temp
cls
echo Очистка временных файлов ShOs...
if exist "%TEMP%\ShOsSetup\" rd /s /q "%TEMP%\ShOsSetup" >nul 2>&1
if exist "%TEMP%\shos_*.txt" del "%TEMP%\shos_*.txt" >nul 2>&1
echo Временные файлы удалены.
timeout /t 2 /nobreak >nul
goto main

:shortcut
cls
echo Пересоздание ярлыка ShOs на рабочем столе...
set "shortcut=%USERPROFILE%\Desktop\ShOs.lnk"
if exist "%shortcut%" del "%shortcut%" >nul
powershell -Command "$WS = New-Object -ComObject WScript.Shell; $SC = $WS.CreateShortcut('%shortcut%'); $SC.TargetPath = 'mshta.exe'; $SC.Arguments = '%CD%\desktop.hta'; $SC.WorkingDirectory = '%CD%'; $SC.IconLocation = '%CD%\system\ICONS.dll'; $SC.Save()"
echo Ярлык создан.
timeout /t 2 /nobreak >nul
goto main

:open_folder
cls
echo Открытие папки ShOs...
start explorer "%CD%"
goto main

:hide_folder
cls
echo Скрытие папки ShOs...
attrib +s +h "%CD%"
attrib +s +h "%CD%\*" /s /d
echo Папка скрыта.
timeout /t 2 /nobreak >nul
goto main

:show_folder
cls
echo Отображение папки ShOs...
attrib -s -h "%CD%"
attrib -s -h "%CD%\*" /s /d
echo Папка показана.
timeout /t 2 /nobreak >nul
goto main

:backup
cls
echo Создание резервной копии пользовательских папок...
echo.
set "folders=Documents Music Pictures Videos Desktop Favorites Saved Games OneDrive"
set "backup_name=UserBackup_%date:~-4,4%%date:~-10,2%%date:~-7,2%.zip"
set "backup_path=%USERPROFILE%\Desktop\%backup_name%"

if exist "%backup_path%" del "%backup_path%"

for %%i in (%folders%) do (
    if exist "%USERPROFILE%\%%i" (
        echo Добавляю папку: %%i
        powershell -Command "Add-Type -AssemblyName System.IO.Compression.FileSystem; [System.IO.Compression.ZipFile]::CreateFromDirectory('%USERPROFILE%\%%i', '%backup_path%')" 2>nul
    )
)

echo.
echo Резервная копия создана: %backup_path%
timeout /t 3 /nobreak >nul
goto main