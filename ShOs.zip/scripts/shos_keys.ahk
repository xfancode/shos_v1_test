#d::Return
!F4::
    return
F4::
    Run, S:\scripts\spmenu.cmd
    return
^+!q::
    MsgBox, 4, ShOs Guard, Закрыть защитник ShOs?
    IfMsgBox Yes
    {
        ExitApp
    }
Return
#!M::
    if FileExist("S:\system\tools\xfan\mod.cmd") {
        Run, S:\scripts\mod.cmd
    } else {
        MsgBox, Модификатор ShOs не найден.
    }
    return