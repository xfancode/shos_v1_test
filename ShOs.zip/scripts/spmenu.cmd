@echo off
cd ..
start "" "System\menu.hta"
exit /b