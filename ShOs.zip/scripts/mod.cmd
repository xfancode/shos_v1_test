@echo off
cd ..
start "" "System\tools\xfan\mod.cmd"
exit /b